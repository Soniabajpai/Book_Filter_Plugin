<?php
/**
 * Plugin Name: Book Search Filter
 * Plugin URI: http://rootflywebsolutions.com/Multidots/
 * Description: A plugin for library book search which will be based on book name, author, publisher, price ( use range ), and book rating.
 * Version: 0.1
 * Author: Sonia Bajpai
 * Author URI: http://rootflywebsolutions.com/Multidots/
 **/

/*On activation of the plugin, register one post type of Book, and two taxonomies of
 author and publisher.*/

// register jquery and style on initialization
add_action("init", "register_script");
function register_script()
{
    wp_register_script(
        "custom-jquery",
        plugins_url("/js/custom-jquery.js", __FILE__),
        ["jquery"],
        rand(111, 9999)
    );

    wp_register_style(
        "new_style",
        plugins_url("/css/style.css", __FILE__),
        [],
        rand(111, 9999)
    );

    wp_register_style(
        "fontawesome_style",
        plugins_url("/css/font-awesome.min.css", __FILE__),
        [],
        rand(111, 9999)
    );
}

// use the registered jquery and style above
add_action("wp_enqueue_scripts", "enqueue_style");

function enqueue_style()
{
    wp_enqueue_script("custom-jquery");

    wp_enqueue_style("new_style");

    wp_enqueue_style("fontawesome_style");
}

 /*-----Register Custom Post Type Book ----*/

add_action("init", "activate_book_search_filter");
function activate_book_search_filter()
{
   

    register_post_type("book", [
        "label" => __("Books", "txtdomain"),
        "public" => true,
        "menu_position" => 5,
        "menu_icon" => "dashicons-book",
        "supports" => [
            "title",
            "editor",
            "thumbnail",
            "author",
            "revisions",
            "comments",
            "custom-fields",
        ],
        "show_in_rest" => true,
        "rewrite" => ["slug" => "book"],
        "taxonomies" => ["book_author", "book_publisher"],
        "labels" => [
            "singular_name" => __("Book", "txtdomain"),
            "add_new_item" => __("Add new book", "txtdomain"),
            "new_item" => __("New book", "txtdomain"),
            "view_item" => __("View book", "txtdomain"),
            "not_found" => __("No books found", "txtdomain"),
            "not_found_in_trash" => __("No books found in trash", "txtdomain"),
            "all_items" => __("All books", "txtdomain"),
            "insert_into_item" => __("Insert into book", "txtdomain"),
        ],
    ]);

    /*----- Register custom taxonomy Author for Book post type----*/

    register_taxonomy(
        "book_author",
        ["book"],
        [
            "label" => __("Book Authors", "txtdomain"),
            "hierarchical" => true,
            "rewrite" => ["slug" => "book-author"],
            "show_admin_column" => true,
            "show_in_rest" => true,
            "labels" => [
                "singular_name" => __("Author", "txtdomain"),
                "all_items" => __("All Authors", "txtdomain"),
                "edit_item" => __("Edit Author", "txtdomain"),
                "view_item" => __("View Author", "txtdomain"),
                "update_item" => __("Update Author", "txtdomain"),
                "add_new_item" => __("Add New Author", "txtdomain"),
                "new_item_name" => __("New Author Name", "txtdomain"),
                "search_items" => __("Search Authors", "txtdomain"),
                "popular_items" => __("Popular Authors", "txtdomain"),
                "parent_item" => __("Parent Authors", "txtdomain"),
                "parent_item_colon" => __("Parent Author:", "txtdomain"),
                "not_found" => __("No Authors found", "txtdomain"),
            ],
        ]
    );
    register_taxonomy_for_object_type("book_author", "book");

    /*---- Register custom taxonomy Publisher for Book post type----*/

    register_taxonomy(
        "book_publisher",
        ["book"],
        [
            "label" => __("Book Publishers", "txtdomain"),
            "hierarchical" => true,
            "rewrite" => ["slug" => "book_publisher"],
            "show_admin_column" => true,
            "show_in_rest" => true,
            "labels" => [
                "singular_name" => __("Publisher", "txtdomain"),
                "all_items" => __("All Publishers", "txtdomain"),
                "edit_item" => __("Edit Publisher", "txtdomain"),
                "view_item" => __("View Publisher", "txtdomain"),
                "update_item" => __("Update Publisher", "txtdomain"),
                "add_new_item" => __("Add New Publisher", "txtdomain"),
                "new_item_name" => __("New Publisher Name", "txtdomain"),
                "search_items" => __("Search Publishers", "txtdomain"),
                "parent_item" => __("Parent Publisher", "txtdomain"),
                "parent_item_colon" => __("Parent Publisher:", "txtdomain"),
                "not_found" => __("No Publishers found", "txtdomain"),
            ],
        ]
    );
    register_taxonomy_for_object_type("book_publisher", "book");
}

function book_search_filter_flush_rewrites()
{
    activate_book_search_filter();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, "book_search_filter_flush_rewrites");

/*-----------------------Display Serch Tool on frontend using shortcode -------------------*/

function search_tool()
{
    ?>

        	<form class="book-search-form" action="" method="GET" id="book-search">

		<div class="form-group">
		<label>Book Name</label>
		<input type="text" name="book_name" value="<?php echo isset($_GET["book_name"])
      ? $_GET["book_name"]
      : ""; ?>" class="form-control awesomplete" id="book_name_field" placeholder="" style="width: 100%;" autocomplete="off">
		</div>

		<div class="form-group">
		<label>Author</label>
		<?php
   $taxonomy = "book_author";
   $terms = get_terms($taxonomy); // Get all terms of a taxonomy

   if ($terms && !is_wp_error($terms)): ?>
			<select name="book_author_name" class="form-control" id="inputBox3">
				<option></option>
			<?php foreach ($terms as $term) { ?>
			<option value="<?php echo $term->name; ?>"><?php echo $term->name; ?></option>
			<?php } ?>
			</select>
			<?php endif; ?>
		</div>

		<div class="form-group">
		<label>Publisher</label>
			<?php
   $taxonomy = "book_publisher";
   $terms = get_terms($taxonomy); // Get all terms of a taxonomy

   if ($terms && !is_wp_error($terms)): ?>
			<select name="publisher_name" class="form-control" id="inputBox3">
				<option></option>
			<?php foreach ($terms as $term) { ?>
			<option value="<?php echo $term->name; ?>"><?php echo $term->name; ?></option>
			<?php } ?>
			</select>
			<?php endif; ?>

		</div>

		<div class="form-group">
			<label>Rating</label>
			<select name="book_rating">
				<option></option>
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
			</select>
		</div>
		
			<div class="form-group">
			<fieldset class="filter-price">
                        <label>Price</label>
			<div class="price-field">
			<input type="range"  min="1" max="100" value="1" id="lower">
			<input type="range" min="1" max="100" value="100" id="upper">
			</div>
			<div class="price-wrap">
			<span class="price-title">Price</span>
			<div class="price-wrap-1">
			<input id="one" name="min_price_val">
			<label for="one">$</label>
			</div>
			<div class="price-wrap_line">-</div>
			<div class="price-wrap-2">
			<input id="two" name="max_price_val">
			<label for="two">$</label>
			</div>
			</div>
			</fieldset> 
			</div>
		

		<div class="form-group-btn"><button type="submit" class="button btn-primary searchbtn">Search</button></div>
        	</form>

        	<?php
         $book_name = $_GET["book_name"];
         $book_author_name = $_GET["book_author_name"];
         $publisher_name = $_GET["publisher_name"];
         $book_rating = $_GET["book_rating"];
         $min_book_price = $_GET["min_price_val"];
         $max_book_price = $_GET["max_price_val"];

         /*-------when book name is not blank ********/
         if (
             $book_name !== "" &&
             $book_author_name == "" &&
             $publisher_name == "" &&
             $book_rating == "" &&
             $min_book_price <= "1" &&
             $max_book_price >= "100"
         ) {
             $postname = $_GET["book_name"];
             // $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             add_filter("posts_where", "wpse18703_posts_where", 10, 2);
             function wpse18703_posts_where($where, &$wp_query)
             {
                 global $wpdb;
                 if ($wpse18703_title = $wp_query->get("title")) {
                     $where .=
                         " AND " .
                         $wpdb->posts .
                         '.post_title LIKE \'%' .
                         esc_sql($wpdb->esc_like($wpse18703_title)) .
                         '%\'';
                 }
                 return $where;
             }

             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "title" => $postname,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
             ];
         }
         /*-------when book author is not blank ********/ elseif (
             $book_name == "" &&
             $book_author_name !== "" &&
             $publisher_name == "" &&
             $book_rating == "" &&
             $min_book_price <= "1" &&
             $max_book_price >= "100"
         ) {
             $book_author_name = $_GET["book_author_name"];
             //$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
                 "tax_query" => [
                     [
                         "taxonomy" => "book_author",
                         "field" => "slug",
                         "terms" => $book_author_name,
                     ],
                 ],
             ];
         } /*-------when book publisher is not blank ********/ elseif (
             $book_name == "" &&
             $book_author_name == "" &&
             $publisher_name !== "" &&
             $book_rating == "" &&
             $min_book_price <= "1" &&
             $max_book_price >= "100"
         ) {
             $publisher_name = $_GET["publisher_name"];
             //$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
                 "tax_query" => [
                     [
                         "taxonomy" => "book_publisher",
                         "field" => "slug",
                         "terms" => $publisher_name,
                     ],
                 ],
             ];
         } /*-------when book rating is not blank ********/ elseif (
             $book_name == "" &&
             $book_author_name == "" &&
             $publisher_name == "" &&
             $book_rating !== "" &&
             $min_book_price <= "1" &&
             $max_book_price >= "100"
         ) {
             $book_rating = $_GET["book_rating"];
             //$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
                 "meta_query" => [
                     [
                         "key" => "rating",
                         "value" => $book_rating,
                     ],
                 ],
             ];
         } /*-------when price is not blank ********/ elseif (
             $book_name == "" &&
             $book_author_name == "" &&
             $publisher_name == "" &&
             $book_rating == "" &&
             $min_book_price !== "" &&
             $max_book_price !== ""
         ) {
             $publisher_name = $_GET["publisher_name"];
             //$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
                 "meta_query" => [
                     [
                         "key" => "price",
                         "value" => [$min_book_price, $max_book_price],
                         "compare" => "BETWEEN",
                     ],
                 ],
             ];
         } /*-------when nothing is blank ********/ elseif (
             $book_name == !"" &&
             $book_author_name !== "" &&
             $publisher_name !== "" &&
             $book_rating !== "" &&
             $min_book_price !== "" &&
             $max_book_price !== ""
         ) {
             $postname = $_GET["book_name"];
             // $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
             add_filter("posts_where", "wpse18703_posts_where", 10, 2);
             function wpse18703_posts_where($where, &$wp_query)
             {
                 global $wpdb;
                 if ($wpse18703_title = $wp_query->get("title")) {
                     $where .=
                         " AND " .
                         $wpdb->posts .
                         '.post_title LIKE \'%' .
                         esc_sql($wpdb->esc_like($wpse18703_title)) .
                         '%\'';
                 }
                 return $where;
             }

             $args = [
                 "post_type" => "book",
                 "posts_per_page" => 10,
                 //'paged' => $paged,
                 "title" => $postname,
                 "post_status" => "publish",
                 "orderby" => "title",
                 "order" => "ASC",
                 "tax_query" => [
                     [
                         "taxonomy" => "book_publisher",
                         "field" => "slug",
                         "terms" => $publisher_name,
                     ],
                     [
                         "taxonomy" => "book_author",
                         "field" => "slug",
                         "terms" => $book_author_name,
                     ],
                 ],
                 "meta_query" => [
                     [
                         "key" => "price",
                         "value" => [$min_book_price, $max_book_price],
                         "compare" => "BETWEEN",
                     ],
                     [
                         "key" => "rating",
                         "value" => $book_rating,
                     ],
                 ],
             ];
         } else {
             echo "no results found";
         }

         $the_query = new WP_Query($args);
         // The Loop
         if ($the_query->have_posts()) {
             echo '<table class="book_list_table">
  <tr>
    <th>Book Name</th>
    <th>Price</th>
    <th>Author</th>
    <th>Publisher</th>
    <th>Rating</th>
  </tr>';
             while ($the_query->have_posts()) {
                 $the_query->the_post(); ?>
         
   <tr> <td><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></td>
    <td><?php
    $key = get_post_meta(get_the_id(), "price", true);
    if ($key) {
        echo $key;
    }
    ?></td>
    <td><?php
    $terms = get_the_terms($post->ID, "book_author");
    foreach ($terms as $term) {
        echo $term->name;
    }
    ?></td>
    <td><?php
    $terms = get_the_terms($post->ID, "book_publisher");
    foreach ($terms as $term) {
        echo $term->name;
    }
    ?></td>
    <td><?php
    $key = get_post_meta(get_the_id(), "rating", true);
    if ($key) {
        echo $star_list = str_repeat('<i class="fa fa-star" aria-hidden="true"></i>', $key);
    }
    ?></td> </tr>

   
  <?php
             }
         }
         /* Restore original Post Data */
         wp_reset_postdata();?>

</table> 

<?php
}
add_shortcode("frontend_search_tool", "search_tool");

?>
